# Code of Conduct

Don't have one. Don't want one.

That's the short version.

Now the _long version_:

1. Having a code of conduct means forcing rules on our community. We don't want that. We want to be free of restrictions and just get the project going.
2. We don't care about your political views, your race, gender, hair color, tatoos or whatever. We just don't. And we don't ask. Because it has nothing to do with this project.
3. We do care about the project, and the code. And nothing else.

If we can't be civil among each other, then having a code of conduct won't help either.
